package com.noxproducao.legendaai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.util.Log

/**
 * Captura o áudio que está sendo reproduzido por outros apps
 * (YouTube, Twitch, etc) usando MediaProjection.
 *
 * NÃO usa o microfone — captura diretamente do pipeline de áudio do sistema.
 *
 * Requer Android 10 (API 29)+.
 */
class AudioCaptureManager(
    private val mediaProjection: MediaProjection,
    private val onAudioChunk: (wav: ByteArray) -> Unit,
    private val onSilence: () -> Unit = {},
    private val chunkDurationMs: Int = 3000   // 3 segundos por chunk
) {
    companion object {
        private const val TAG          = "AudioCapture"
        const val  SAMPLE_RATE        = 16000   // Whisper prefere 16kHz
        private const val CHANNELS     = AudioFormat.CHANNEL_IN_MONO
        private const val ENCODING     = AudioFormat.ENCODING_PCM_16BIT
        private const val SILENCE_RMS  = 150.0  // abaixo disso = silêncio
    }

    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var isRunning = false

    fun start() {
        if (isRunning) return
        isRunning = true

        // Configura captura de áudio de outros apps (não mic)
        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)          // vídeos, músicas
            .addMatchingUsage(AudioAttributes.USAGE_GAME)           // jogos
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setEncoding(ENCODING)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(CHANNELS)
            .build()

        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNELS, ENCODING)
        val bufferSize = maxOf(minBuffer, SAMPLE_RATE * 2)  // ao menos 1 segundo de buffer

        audioRecord = AudioRecord.Builder()
            .setAudioPlaybackCaptureConfig(captureConfig)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(bufferSize)
            .build()

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "Falha ao inicializar AudioRecord")
            return
        }

        audioRecord?.startRecording()
        Log.d(TAG, "Captura iniciada — $SAMPLE_RATE Hz, mono, 16bit")

        captureThread = Thread {
            val chunkSamples = (SAMPLE_RATE * chunkDurationMs / 1000)
            val chunkBytes = chunkSamples * 2   // 16bit = 2 bytes/sample
            val accumulator = ArrayList<Byte>(chunkBytes)
            val readBuffer = ByteArray(1024)

            while (isRunning) {
                val read = audioRecord?.read(readBuffer, 0, readBuffer.size) ?: break
                if (read > 0) {
                    for (i in 0 until read) accumulator.add(readBuffer[i])

                    // Quando acumulou chunk completo, processa
                    if (accumulator.size >= chunkBytes) {
                        val pcm = accumulator.toByteArray()
                        accumulator.clear()

                        val rms = WavEncoder.calculateRms(pcm)
                        if (rms < SILENCE_RMS) {
                            // Silêncio — não manda pro STT (economiza API calls)
                            onSilence()
                        } else {
                            val wav = WavEncoder.encode(pcm, SAMPLE_RATE)
                            onAudioChunk(wav)
                        }
                    }
                }
            }
        }.also { it.name = "audio-capture-thread"; it.start() }
    }

    fun stop() {
        isRunning = false
        captureThread?.interrupt()
        captureThread = null
        audioRecord?.apply { stop(); release() }
        audioRecord = null
        Log.d(TAG, "Captura encerrada")
    }
}
