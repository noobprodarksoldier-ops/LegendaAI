package com.noxproducao.legendaai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_PROJECTION = 1001
        private const val REQ_AUDIO      = 1002
        private const val PREFS_NAME     = "legendaai_prefs"
        private const val PREF_API_KEY   = "whisper_api_key"
    }

    private lateinit var mpm: MediaProjectionManager
    private lateinit var tvStatus: TextView
    private lateinit var etApiKey: EditText
    private lateinit var spinnerSource: Spinner
    private lateinit var spinnerTarget: Spinner

    private val LANG_LABELS = arrayOf(
        "Inglês (en)", "Português (pt)", "Espanhol (es)",
        "Japonês (ja)", "Coreano (ko)", "Francês (fr)"
    )
    private val LANG_CODES = arrayOf("en", "pt", "es", "ja", "ko", "fr")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mpm      = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        tvStatus = findViewById(R.id.tvStatus)
        etApiKey = findViewById(R.id.etApiKey)

        // Carrega API key salva
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        etApiKey.setText(prefs.getString(PREF_API_KEY, ""))

        // Spinners de idioma
        spinnerSource = findViewById(R.id.spinnerSource)
        spinnerTarget = findViewById(R.id.spinnerTarget)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, LANG_LABELS)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerSource.adapter = adapter
        spinnerTarget.adapter = adapter
        spinnerSource.setSelection(0)
        spinnerTarget.setSelection(1)

        findViewById<Button>(R.id.btnStart).setOnClickListener { handleStart() }
        findViewById<Button>(R.id.btnStop).setOnClickListener  { handleStop()  }
    }

    private fun handleStart() {
        val apiKey = etApiKey.text.toString().trim()
        if (apiKey.isEmpty()) {
            setStatus("❌ Insira sua OpenAI API Key")
            return
        }

        // Salva a API key para próximas sessões
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(PREF_API_KEY, apiKey).apply()

        // 1) Permissão de overlay
        if (!Settings.canDrawOverlays(this)) {
            setStatus("⚠️ Ative 'Aparecer sobre outros apps' e volte")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }

        // 2) RECORD_AUDIO (exigida pelo AudioRecord mesmo sem mic)
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }

        // 3) MediaProjection
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    private fun handleStop() {
        stopService(Intent(this, OverlayService::class.java))
        setStatus("⏹ Parado")
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == REQ_AUDIO && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
        } else {
            setStatus("❌ Permissão de áudio negada")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            launchService(resultCode, data)
        }
    }

    private fun launchService(resultCode: Int, data: Intent) {
        val src    = LANG_CODES[spinnerSource.selectedItemPosition]
        val tgt    = LANG_CODES[spinnerTarget.selectedItemPosition]
        val apiKey = etApiKey.text.toString().trim()

        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_CODE,    resultCode)
            putExtra(OverlayService.EXTRA_DATA,    data)
            putExtra(OverlayService.EXTRA_SRC,     src)
            putExtra(OverlayService.EXTRA_TGT,     tgt)
            putExtra(OverlayService.EXTRA_API_KEY, apiKey)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        setStatus("✅ Capturando áudio do app ($src → $tgt)\nMinimize e abra o YouTube/Twitch")
    }

    private fun setStatus(msg: String) { tvStatus.text = msg }
}
