package com.noxproducao.legendaai

import android.util.Log
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Cliente para a OpenAI Whisper API.
 *
 * Envia chunks de áudio WAV e retorna o texto transcrito.
 * Roda em thread de background — callbacks chegam nela também;
 * use Handler(Looper.getMainLooper()) para atualizar a UI.
 *
 * Custo: ~$0.006 por minuto de áudio (modelo whisper-1).
 * Com chunks de 3s → ~$0.0003 por chunk.
 */
class WhisperSTT(private val apiKey: String) {

    companion object {
        private const val TAG      = "WhisperSTT"
        private const val ENDPOINT = "https://api.openai.com/v1/audio/transcriptions"
        private const val MODEL    = "whisper-1"
        private const val BOUNDARY = "LegendaAI_Boundary_XYZ789"
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    /**
     * Envia um WAV para o Whisper e chama onResult com o texto.
     * @param wavBytes  Arquivo WAV completo (header + PCM)
     * @param language  Código BCP-47 do idioma (ex: "en", "ja")
     * @param onResult  Chamado com o texto ou null em caso de erro
     */
    fun transcribe(
        wavBytes: ByteArray,
        language: String,
        onResult: (String?) -> Unit
    ) {
        executor.submit {
            try {
                val result = sendRequest(wavBytes, language)
                onResult(result)
            } catch (e: Exception) {
                Log.e(TAG, "Erro na transcrição: ${e.message}")
                onResult(null)
            }
        }
    }

    private fun sendRequest(wavBytes: ByteArray, language: String): String? {
        val url = URL(ENDPOINT)
        val conn = url.openConnection() as HttpURLConnection

        conn.apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$BOUNDARY")
        }

        // Monta o body multipart manualmente (sem OkHttp)
        val body = buildMultipart(wavBytes, language)
        conn.setFixedLengthStreamingMode(body.size)

        conn.outputStream.use { it.write(body) }

        val responseCode = conn.responseCode
        Log.d(TAG, "Whisper HTTP $responseCode")

        if (responseCode != 200) {
            val err = conn.errorStream?.bufferedReader()?.readText()
            Log.e(TAG, "Whisper erro: $err")
            return null
        }

        val response = conn.inputStream.bufferedReader().readText()
        Log.d(TAG, "Whisper resposta: $response")

        return JSONObject(response).optString("text", null)
    }

    private fun buildMultipart(wavBytes: ByteArray, language: String): ByteArray {
        val out = ByteArrayOutputStream()
        val writer = PrintWriter(OutputStreamWriter(out, "UTF-8"), true)

        // Campo: model
        writer.append("--$BOUNDARY\r\n")
        writer.append("Content-Disposition: form-data; name=\"model\"\r\n\r\n")
        writer.append("$MODEL\r\n")
        writer.flush()

        // Campo: language
        writer.append("--$BOUNDARY\r\n")
        writer.append("Content-Disposition: form-data; name=\"language\"\r\n\r\n")
        writer.append("$language\r\n")
        writer.flush()

        // Campo: response_format
        writer.append("--$BOUNDARY\r\n")
        writer.append("Content-Disposition: form-data; name=\"response_format\"\r\n\r\n")
        writer.append("json\r\n")
        writer.flush()

        // Campo: file (o WAV binário)
        writer.append("--$BOUNDARY\r\n")
        writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n")
        writer.append("Content-Type: audio/wav\r\n\r\n")
        writer.flush()

        out.write(wavBytes)

        writer.append("\r\n--$BOUNDARY--\r\n")
        writer.flush()

        return out.toByteArray()
    }

    fun shutdown() {
        executor.shutdown()
    }
}
