package com.noxproducao.legendaai

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Converte bytes PCM brutos em um arquivo WAV válido.
 * Whisper e a maioria das APIs STT aceitam WAV como input.
 */
object WavEncoder {

    fun encode(
        pcmBytes: ByteArray,
        sampleRate: Int = 16000,
        channels: Int = 1,
        bitsPerSample: Int = 16
    ): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val dataSize = pcmBytes.size
        val chunkSize = 36 + dataSize

        val out = ByteArrayOutputStream()

        fun writeInt(value: Int) {
            val buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
            buf.putInt(value)
            out.write(buf.array())
        }

        fun writeShort(value: Int) {
            val buf = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
            buf.putShort(value.toShort())
            out.write(buf.array())
        }

        // RIFF header
        out.write("RIFF".toByteArray())
        writeInt(chunkSize)
        out.write("WAVE".toByteArray())

        // fmt sub-chunk
        out.write("fmt ".toByteArray())
        writeInt(16)            // sub-chunk size para PCM
        writeShort(1)           // AudioFormat = PCM
        writeShort(channels)
        writeInt(sampleRate)
        writeInt(byteRate)
        writeShort(blockAlign)
        writeShort(bitsPerSample)

        // data sub-chunk
        out.write("data".toByteArray())
        writeInt(dataSize)
        out.write(pcmBytes)

        return out.toByteArray()
    }

    /**
     * Calcula o RMS do PCM para detectar silêncio.
     * Retorna um valor entre 0.0 e ~32767.0
     */
    fun calculateRms(pcmBytes: ByteArray): Double {
        if (pcmBytes.size < 2) return 0.0
        var sum = 0.0
        var count = 0
        var i = 0
        while (i < pcmBytes.size - 1) {
            val sample = ((pcmBytes[i + 1].toInt() shl 8) or (pcmBytes[i].toInt() and 0xFF)).toShort()
            sum += sample.toDouble() * sample.toDouble()
            count++
            i += 2
        }
        return if (count == 0) 0.0 else Math.sqrt(sum / count)
    }
}
