package com.noxproducao.legendaai

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.*

/**
 * OverlayService — Phase 2
 *
 * Pipeline completo:
 *   MediaProjection
 *     → AudioRecord (AudioPlaybackCapture, sem microfone)
 *       → WavEncoder (PCM → WAV)
 *         → WhisperSTT (OpenAI API)
 *           → ML Kit Translate (on-device)
 *             → Overlay Window (legenda flutuante)
 */
class OverlayService : Service() {

    companion object {
        private const val TAG        = "LegendaAI"
        private const val CHANNEL_ID = "legendaai_svc"
        private const val NOTIF_ID   = 42
        const val  EXTRA_API_KEY     = "whisperApiKey"
        const val  EXTRA_SRC         = "sourceLang"
        const val  EXTRA_TGT         = "targetLang"
        const val  EXTRA_CODE        = "resultCode"
        const val  EXTRA_DATA        = "data"
    }

    // ── UI ───────────────────────────────────────────────────────────────────
    private lateinit var windowManager: WindowManager
    private var overlayView: View?    = null
    private var tvSubtitle: TextView? = null

    // ── Config ───────────────────────────────────────────────────────────────
    private var sourceLang   = "en"
    private var targetLang   = "pt"
    private var whisperApiKey = ""

    // ── Core components ──────────────────────────────────────────────────────
    private var audioCapture: AudioCaptureManager? = null
    private var whisperSTT:   WhisperSTT?          = null
    private var translator:   Translator?           = null
    private var translatorReady = false

    private val handler = Handler(Looper.getMainLooper())

    // ─────────────────────────────────────────────────────────────────────────
    // Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())

        sourceLang    = intent?.getStringExtra(EXTRA_SRC)     ?: "en"
        targetLang    = intent?.getStringExtra(EXTRA_TGT)     ?: "pt"
        whisperApiKey = intent?.getStringExtra(EXTRA_API_KEY) ?: ""

        val resultCode     = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val projectionData = intent.getParcelableExtra<Intent>(EXTRA_DATA)             ?: return START_NOT_STICKY

        setupOverlay()
        setupTranslator()
        setupAudioCapture(resultCode, projectionData)

        return START_STICKY
    }

    override fun onDestroy() {
        audioCapture?.stop()
        whisperSTT?.shutdown()
        translator?.close()
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─────────────────────────────────────────────────────────────────────────
    // Overlay Window
    // ─────────────────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun setupOverlay() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_view, null)
        tvSubtitle  = overlayView!!.findViewById(R.id.tvSubtitle)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        windowManager.addView(overlayView, params)

        // Suporte a arrastar
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        overlayView!!.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN  -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE  -> {
                    params.x = sx + (e.rawX - tx).toInt()
                    params.y = sy + (e.rawY - ty).toInt()
                    runCatching { windowManager.updateViewLayout(overlayView, params) }
                    true
                }
                else -> false
            }
        }

        showSubtitle("🎬 Iniciando captura...")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Audio Capture (Phase 2 - sem microfone)
    // ─────────────────────────────────────────────────────────────────────────

    private fun setupAudioCapture(resultCode: Int, projectionData: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mediaProjection = mpm.getMediaProjection(resultCode, projectionData)

        if (mediaProjection == null) {
            showSubtitle("❌ Falha ao obter MediaProjection")
            return
        }

        whisperSTT = WhisperSTT(whisperApiKey)

        audioCapture = AudioCaptureManager(
            mediaProjection = mediaProjection,
            chunkDurationMs = 3000,

            onAudioChunk = { wavBytes ->
                // Chegou um chunk de ~3s de áudio → manda pro Whisper
                Log.d(TAG, "Chunk: ${wavBytes.size} bytes → Whisper")
                showSubtitle("🔄 Reconhecendo...")

                whisperSTT?.transcribe(wavBytes, sourceLang) { text ->
                    if (text.isNullOrBlank()) {
                        Log.w(TAG, "Whisper retornou vazio")
                        return@transcribe
                    }
                    Log.d(TAG, "Whisper: $text")
                    translateAndShow(text)
                }
            },

            onSilence = {
                // Silêncio detectado — não gasta API call
                Log.v(TAG, "Silêncio detectado, pulando chunk")
            }
        )

        audioCapture?.start()
        showSubtitle("✅ Capturando áudio do app...")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ML Kit Translation
    // ─────────────────────────────────────────────────────────────────────────

    private fun setupTranslator() {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang.toMLKit())
            .setTargetLanguage(targetLang.toMLKit())
            .build()

        translator = Translation.getClient(options)

        translator!!.downloadModelIfNeeded()
            .addOnSuccessListener { translatorReady = true }
            .addOnFailureListener { Log.e(TAG, "Modelo falhou: ${it.message}") }
    }

    private fun translateAndShow(text: String) {
        if (!translatorReady) {
            showSubtitle(text)
            return
        }
        translator?.translate(text)
            ?.addOnSuccessListener { showSubtitle(it) }
            ?.addOnFailureListener { showSubtitle(text) }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private fun showSubtitle(text: String) {
        handler.post { tvSubtitle?.text = text }
    }

    private fun String.toMLKit(): String = when (this) {
        "pt" -> TranslateLanguage.PORTUGUESE
        "es" -> TranslateLanguage.SPANISH
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        "fr" -> TranslateLanguage.FRENCH
        else -> TranslateLanguage.ENGLISH
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "LegendaAI", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LegendaAI 🎬")
            .setContentText("Capturando áudio — legenda ativa")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
}
